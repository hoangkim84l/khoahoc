<div class="clear"></div>
<div class="clear mt30"></div>
<div id="footer">
	<div class="wrapper">
		
		<p>Bản quyền &copy; 2019 Khoa học và Công nghệ</p>
		
	</div>
	
</div>