<div class="top_line">
  <div class="container">
    <div class="row">
      <div class="col-lg-6 col-md-7 col-sm-12 col-xs-12 pull-left">
        <ul class="contact-top">
          <li><i class="icon-location"></i> 455 Martinson, Los Angeles</li>
          <li><i class="icon-mobile"></i> 8 (043) 567 - 89 - 30</li>
          <li><i class="icon-mail"></i> support@email.com</li>
        </ul>
      </div>
      <div class="col-lg-6 col-md-5 pull-right hidden-phone">
        <ul class="social-links">
          <li><a href="#"><i class="fa fa-facebook"></i></a></li>
          <li><a href="#"><i class="fa fa-twitter"></i></a></li>
          <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
          <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
          <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
          <li><a href="#"><i class="fa fa-vk"></i></a></li>
          <li id="search-btn"><a href="#"><i class="icon-search"></i></a></li>
        </ul>
        <div class="search-input" id="search-input" style="display: none;">
          <input id="s-input" type="text" placeholder="Search...">
        </div>
      </div> 
    </div>
  </div>
</div>