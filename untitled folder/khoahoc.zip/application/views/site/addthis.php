<div class="nav-container" style="height: auto;">
  <nav>
    <div class="container">
      <div class="row">
        <div class="col-lg-3 pull-left"><div class="logo"><a href="index-2.html"><img src="<?php echo public_url()?>site/assets/images/logo.png" alt=""></a></div></div>
        <div class="col-lg-9 pull-right">
          <div class="menu">
            <div id="dl-menu" class="dl-menuwrapper">
              <button class="dl-trigger">Open Menu</button>
              <ul class="dl-menu">
                <li class="current"><a href="#">Trang chủ</a></li>
                <li><a href="#">Giới thiệu</a></li>                
                <li><a href="#">Sản phẩm</a>
                  <ul class="dl-submenu">
                    <li><a href="about.html">About Us</a></li>
                    <li><a href="services.html">Services</a></li>
                    <li><a href="contacts.html">Contact</a></li>
                    <li><a href="pricing_tables.html">Pricing Tables</a></li>
                    <li><a href="404.html">404 Error</a></li>
                    <li><a href="faq.html">F.A.Q</a></li>
                    <li>
                      <a href="#">Third Level Menu</a>
                      <ul class="dl-submenu">
                        <li><a href="#">Sublevel Title</a></li>
                        <li><a href="#">Another Menu</a></li>
                        <li><a href="#">And One More</a></li>
                      </ul>
                    </li>
                  </ul>
                </li>
                <li><a href="#">Dịch vụ</a></li>
                <li><a href="#">Bài viết</a></li>
                <li><a href="contact">Liên hệ</a></li>
              </ul>
            </div> 
          </div>        
        </div>
      </div>
    </div>
  </nav>
</div>