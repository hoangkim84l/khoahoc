<div class="tp-banner-container" style="height:500px;">
  <div class="tp-banner" >
    <ul style="display:none;">
      <li data-transition="fade" data-slotamount="7" data-masterspeed="700" >
        <img src="<?php echo public_url()?>site/assets/images/fon1.jpg"  alt=""  data-bgfit="cover" data-bgposition="center center" data-bgrepeat="no-repeat">
        <div class="tp-caption largeblackbg sfb"
        data-x="center"
        data-y="95"
        data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
        data-speed="500"
        data-start="800"
        data-easing="Back.easeOut"
        data-endspeed="500"
        data-endeasing="Power4.easeIn"
        data-captionhidden="on"
        style="z-index: 4">Refined Modern Corporate Style
      </div>
      <div class="tp-caption largeborder skewfromrightshort"
      data-x="center"
      data-y="200"
      data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
      data-speed="500"
      data-start="1100"
      data-easing="Back.easeOut"
      data-endspeed="500"
      data-endeasing="Power4.easeIn"
      data-captionhidden="on"
      style="z-index: 9">
    </div>
    <div class="tp-caption largetext sft"
    data-x="center"
    data-y="250"
    data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
    data-speed="500"
    data-start="1400"
    data-easing="Back.easeOut"
    data-endspeed="500"
    data-endeasing="Power4.easeIn"
    data-captionhidden="on"
    style="z-index: 9">Pellentesque luctus ac lorem aenean sagittis magna purus vehicsula. Tristique nunc a felis ultricies, ultrices erat<br>Suspendisse velit ticol sodales, viverra sigirton vitae, accumsan orci mauris nec ipsum
  </div>
  <div class="tp-caption largebutton lfb"
  data-x="center"
  data-y="360"
  data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
  data-speed="500"
  data-start="1800"
  data-easing="Back.easeOut"
  data-endspeed="500"
  data-endeasing="Power4.easeIn"
  data-captionhidden="on"
  style="z-index: 9"><a href="https://themeforest.net/item/xenia-refined-html-5-css-3-corporate-template/6863456?ref=DankovThemes">Purchase now</a>
</div>
</li>
<li data-transition="random" data-slotamount="7" data-masterspeed="700" >
  <img src="<?php echo public_url()?>site/assets/images/fon2.jpg"  alt=""  data-bgfit="cover" data-bgposition="center center" data-bgrepeat="no-repeat">
  <div class="tp-caption largeblackbg sfb"
  data-x="30"
  data-y="80"
  data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
  data-speed="500"
  data-start="800"
  data-easing="Back.easeOut"
  data-endspeed="500"
  data-endeasing="Power4.easeIn"
  data-captionhidden="on"
  style="z-index: 4">Fully Responsive & Retina
</div>
<div class="tp-caption largetext sft"
data-x="30"
data-y="170"
data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
data-speed="500"
data-start="1100"
data-easing="Back.easeOut"
data-endspeed="500"
data-endeasing="Power4.easeIn"
data-captionhidden="on"
style="z-index: 9;text-align:left;">Pellentesque luctus ac lorem aenean sagittis magna purus vehicsula.<br> Tristique nunc a felis ultricies, ultrices eratSuspendisse velit ticol sodales
</div>
<div class="tp-caption largebutton lft"
data-x="30"
data-y="270"
data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
data-speed="500"
data-start="2400"
data-easing="Back.easeOut"
data-endspeed="500"
data-endeasing="Power4.easeIn"
data-captionhidden="on"
style="z-index: 9"><a href="https://themeforest.net/item/xenia-refined-html-5-css-3-corporate-template/6863456?ref=DankovThemes">Purchase now</a>
</div>
<div class="tp-caption lfb"
data-x="730"
data-y="40"
data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
data-speed="500"
data-start="1650"
data-easing="Back.easeOut"
data-endspeed="500"
data-endeasing="Power4.easeIn"
data-captionhidden="on"
style="z-index: 9"><img src="<?php echo public_url()?>site/assets/images/imac.png" alt="">
</div>
<div class="tp-caption lfb"
data-x="760"
data-y="405"
data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
data-speed="500"
data-start="1850"
data-easing="Back.easeOut"
data-endspeed="500"
data-endeasing="Power4.easeIn"
data-captionhidden="on"
style="z-index: 9"><img src="<?php echo public_url()?>site/assets/images/keyboard.png" alt="">
</div>
<div class="tp-caption lfb"
data-x="1020"
data-y="405"
data-customout="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0.75;scaleY:0.75;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
data-speed="500"
data-start="2000"
data-easing="Back.easeOut"
data-endspeed="500"
data-endeasing="Power4.easeIn"
data-captionhidden="on"
style="z-index: 9"><img src="<?php echo public_url()?>site/assets/images/mouse.png" alt="">
</div>
</li>
<li data-transition="random" data-slotamount="7" data-masterspeed="700" >
  <img src="<?php echo public_url()?>site/assets/images/fon3.jpg"  alt=""  data-bgfit="cover" data-bgposition="center center" data-bgrepeat="no-repeat">
  <div class="tp-caption lfb"
  data-x="30"
  data-y="40"
  data-speed="500"
  data-start="800"
  data-easing="Back.easeOut"
  data-endspeed="500"
  data-endeasing="Power4.easeIn"
  data-captionhidden="on"
  style="z-index: 9"><img src="<?php echo public_url()?>site/assets/images/man.png" alt="">
</div>
<div class="tp-caption largeblackbg sfb"
data-x="550"
data-y="75"
data-speed="500"
data-start="1400"
data-easing="Back.easeOut"
data-endspeed="500"
data-endeasing="Power4.easeIn"
data-captionhidden="on"
style="z-index: 9">We Love Our Clients
</div>
<div class="tp-caption largetext sft"
data-x="550"
data-y="160"
data-speed="500"
data-start="1600"
data-easing="Back.easeOut"
data-endspeed="500"
data-endeasing="Power4.easeIn"
data-captionhidden="on"
style="z-index: 9;text-align:left;">Pellentesque luctus ac lorem aenean sagittis magna purus vehicsula.<br> Tristique nunc a felis ultricies, ultrices eratSuspendisse velit ticol sodales
</div>
<div class="tp-caption largeblackbg sfb"
data-x="540"
data-y="250"
data-speed="500"
data-start="1800"
data-easing="Back.easeOut"
data-endspeed="500"
data-endeasing="Power4.easeIn"
data-captionhidden="on"
style="z-index: 9"><i class="icon-user"></i>
</div>
<div class="tp-caption largeblackbg sfb"
data-x="625"
data-y="245"
data-speed="500"
data-start="2000"
data-easing="Back.easeOut"
data-endspeed="500"
data-endeasing="Power4.easeIn"
data-captionhidden="on"
style="z-index: 9"><i class="glyphicon glyphicon-plus"></i>
</div>
<div class="tp-caption largeblackbg sfb"
data-x="682"
data-y="250"
data-speed="500"
data-start="2200"
data-easing="Back.easeOut"
data-endspeed="500"
data-endeasing="Power4.easeIn"
data-captionhidden="on"
style="z-index: 9"><img src="<?php echo public_url()?>site/assets/images/logo-slider.png" alt="">
</div>
<div class="tp-caption largeblackbg sfb"
data-x="765"
data-y="250"
data-speed="500"
data-start="2400"
data-easing="Back.easeOut"
data-endspeed="500"
data-endeasing="Power4.easeIn"
data-captionhidden="on"
style="z-index: 9">=
</div>
<div class="tp-caption largeblackbg sfb"
data-x="815"
data-y="250"
data-speed="500"
data-start="2600"
data-easing="Back.easeOut"
data-endspeed="500"
data-endeasing="Power4.easeIn"
data-captionhidden="on"
style="z-index: 9"><i class="icon-heart"></i>
</div>
<div class="tp-caption largebutton lft"
data-x="550"
data-y="350"
data-speed="500"
data-start="2800"
data-easing="Back.easeOut"
data-endspeed="500"
data-endeasing="Power4.easeIn"
data-captionhidden="on"
style="z-index: 9"><a href="https://themeforest.net/item/xenia-refined-html-5-css-3-corporate-template/6863456?ref=DankovThemes">Purchase now</a>
</div>
</div>
</li>
</ul>
</div>
<script type="text/javascript">
  var revapi;
  jQuery(document).ready(function() {
   revapi = jQuery('.tp-banner').revolution({
    delay:9000,
    startwidth:1170,
    startheight:500,
    hideThumbs:10,
    forceFullWidth:"off",
  });
        }); //ready
      </script>