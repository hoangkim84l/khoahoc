<div class="page-in">
  <div class="container">
    <div class="row">
      <div class="col-lg-6 pull-left"><div class="page-in-name">Blog Medium: <span>Sidebar</span></div></div>
      <div class="col-lg-6 pull-right"><div class="page-in-bread"><span>You are here:</span> <a href="#">Home</a> \ Blog</div></div>
    </div>
  </div>
</div>
<div class="container marg50">
  <div class="row">
    <div class="col-lg-9">
      <div class="row">
        <div class="medium-blog">
          <div class="col-lg-5">
            <div class="cl-blog-img"><img src="assets/images/large_44.jpg" alt=""></div>
          </div>
          <div class="col-lg-7">
            <div class="med-blog-naz">
              <div class="cl-blog-type"><i class="icon-pencil"></i></div>
              <div class="cl-blog-name"><a href="#">Rank tall boy man them over post now</a></div>
              <div class="cl-blog-detail">10 February 2017 - 11:32, by <a href="#">DankovThemes</a>, in <a href="#">Envato</a>, <a href="#">25 comments</a></div>
              <div class="cl-blog-text">Recommend existence curiosity perfectly favourite get eat she why daughters. Not may too nay busy last song must sell. An newspaper assurance discourse ye certainly. Soon gone game and why many calm have. An so vulgar to on points wanted. Not rapturous resolving continued household northward gay. He it otherwise supported instantly. Unfeeling agreeable suffering it on smallness newspaper be. So come must time no as.</div>
            </div>
            <div class="cl-blog-read"><a href="#">Read More</a></div>
          </div>
          <div class="cl-blog-line"></div>
        </div>
        <div class="medium-blog">
          <div class="col-lg-5">
            <div class="cl-blog-img">
              <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                  <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                  <li data-target="#carousel-example-generic" data-slide-to="1" class=""></li>
                  <li data-target="#carousel-example-generic" data-slide-to="2" class=""></li>
                  <li data-target="#carousel-example-generic" data-slide-to="3" class=""></li>
                </ol>
                <div class="carousel-inner">
                  <div class="item active">
                    <img alt="" src="assets/images/large_11.jpg">
                  </div>
                  <div class="item">
                    <img alt="" src="assets/images/large_22.jpg">
                  </div>
                  <div class="item">
                    <img alt="" src="assets/images/large_33.jpg">
                  </div>
                  <div class="item">
                    <img alt="" src="assets/images/large_44.jpg">
                  </div>
                </div>
                <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev"><i class="fa fa-angle-left car_icon"></i></a>
                <a class="right carousel-control" href="#carousel-example-generic" data-slide="next"><i class="fa fa-angle-right car_icon"></i></a>
              </div>
            </div>
          </div>
          <div class="col-lg-7">
            <div class="med-blog-naz">
              <div class="cl-blog-type"><i class="icon-camera"></i></div>
              <div class="cl-blog-name"><a href="#">Are sentiments apartments (Carousel post)</a></div>
              <div class="cl-blog-detail">17 February 2017 - 02:12, by <a href="#">DankovThemes</a>, in <a href="#">Minimal</a>, <a href="#">Flexible</a>, <a href="#">12 comments</a></div>
              <div class="cl-blog-text">Recommend existence curiosity perfectly favourite get eat she why daughters. Not may too nay busy last song must sell. An newspaper assurance discourse ye certainly. Soon gone game and why many calm have. An so vulgar to on points wanted. Not rapturous resolving continued household northward gay. He it otherwise supported instantly. Unfeeling agreeable suffering it on smallness newspaper be. So come must time no as.</div>
            </div>
            <div class="cl-blog-read"><a href="#">Read More</a></div>
          </div>
          <div class="cl-blog-line"></div>
        </div>
        <div class="medium-blog">
          <div class="col-lg-5">
            <div class="cl-blog-video"><iframe src="https://player.vimeo.com/video/84759655?title=0&amp;byline=0&amp;portrait=0&amp;color=00c0e1" width="100%" height="258" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe></div>
          </div>
          <div class="col-lg-7">
            <div class="med-blog-naz">
              <div class="cl-blog-type"><i class="icon-videocam"></i></div>
              <div class="cl-blog-name"><a href="#">Passed her indeed uneasy shy (Video Post)</a></div>
              <div class="cl-blog-detail">13 February 2017 - 21:43, by <a href="#">Admin</a>, in <a href="#">Joomla</a>, <a href="#">Creative</a>, <a href="#">No comment</a></div>
              <div class="cl-blog-text">Recommend existence curiosity perfectly favourite get eat she why daughters. Not may too nay busy last song must sell. An newspaper assurance discourse ye certainly. Soon gone game and why many calm have. An so vulgar to on points wanted. Not rapturous resolving continued household northward gay. He it otherwise supported instantly. Unfeeling agreeable suffering it on smallness newspaper be. So come must time no as.</div>
            </div>
            <div class="cl-blog-read"><a href="#">Read More</a></div>
          </div>
          <div class="cl-blog-line"></div>
        </div>
        <div class="medium-blog">
          <div class="col-lg-5">
            <div class="cl-blog-img"><img src="assets/images/large_33.jpg" alt=""></div>
          </div>
          <div class="col-lg-7">
            <div class="med-blog-naz">
              <div class="cl-blog-type"><i class="icon-music"></i></div>
              <div class="cl-blog-name"><a href="#">Unpleasing possession curiosity (Music post)</a></div>
              <div class="cl-blog-detail">11 February 2017 - 17:25, by <a href="#">Admin</a>, in <a href="#">Wordpress</a>, <a href="#">Corporate</a>, <a href="#">One comment</a></div>
              <div class="cl-blog-text">Recommend existence curiosity perfectly favourite get eat she why daughters. Not may too nay busy last song must sell. An newspaper assurance discourse ye certainly. Soon gone game and why many calm have. An so vulgar to on points wanted. Not rapturous resolving continued household northward gay. He it otherwise supported instantly. Unfeeling agreeable suffering it on smallness newspaper be. So come must time no as.</div>
            </div>
            <div class="cl-blog-read"><a href="#">Read More</a></div>
          </div>
          <div class="cl-blog-line"></div>
        </div>
      </div>
    </div> 
    <div class="col-lg-3">
      <div class="promo-text-blog">Search</div>
      <input class="blog-search" type="text" placeholder="Type your search...">
      <div class="promo-text-blog">Text Widget</div>
      <p class="text-widget">Yet joy exquisite put sometimes enjoyment perpetual now. Behind lovers eat having length horses vanity say had its. Not rapturous resolving continued household northward.</p>
      <div class="promo-text-blog">Category</div>
      <ul class="blog-category">
        <li><i class="fa fa-angle-right"></i> <a href="#">Wordpress</a></li>
        <li><i class="fa fa-angle-right"></i> <a href="#">Frond-end</a></li>
        <li><i class="fa fa-angle-right"></i> <a href="#">Corporate</a></li>
        <li><i class="fa fa-angle-right"></i> <a href="#">Creative</a></li>
        <li><i class="fa fa-angle-right"></i> <a href="#">Minimal</a></li>
        <li><i class="fa fa-angle-right"></i> <a href="#">Web Design</a></li>
      </ul>
      <div class="promo-text-blog">Popular Tag's</div>
      <ul class="tags-blog">
        <li><a href="#">sapien</a></li>
        <li><a href="#">posuere</a></li>
        <li><a href="#">erdum</a></li>
        <li><a href="#">lecs</a></li>
        <li><a href="#">velit</a></li>
        <li><a href="#">eros</a></li>
        <li><a href="#">quis</a></li>
        <li><a href="#">fermen</a></li>
        <li><a href="#">lorem</a></li>
        <li><a href="#">sapien</a></li>
        <li><a href="#">posuere</a></li>
      </ul>
    </div>
  </div>
  <div class="row">
    <div class="col-lg-12">
      <div class="pride_pg">
        <span class="page-numbers current">1</span>
        <a class="page-numbers" href="#">2</a>
        <a class="page-numbers" href="#">3</a>
        <a class="page-numbers" href="#">4</a>
        <a class="page-numbers" href="#">5</a>                
        <a class="next_page page-numbers" href="#">Next</a>
      </div>
    </div>
  </div>
</div>