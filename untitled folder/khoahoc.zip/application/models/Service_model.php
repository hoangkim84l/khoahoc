<?php
Class Service_model extends MY_Model
{
    var $table = 'service';
}