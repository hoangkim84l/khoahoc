<?php
class Contact_model extends MY_Model
{
	//ten bang du lieu
	public $table = 'contact';
	
}

