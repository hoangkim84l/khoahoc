﻿	 <div class="container">
            <div class="row">
                <div class="col-12 col-md-4">
                    <div class="footer-single-widget">
                        <a href="<?php echo base_url()?>"><img src="<?php echo base_url('upload/logo/'.$supports->image)?>" alt="<?php echo $supports->address?>" title="<?php echo $supports->introduce?>"</a>
                        <div class="copywrite-text mt-30">
                            <p style="height: 224px;
                                        overflow: hidden;font-family: arrial;
                                     font-size: 18px;"><?php echo $supports->introduce?><br/>
                            
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                        </div>
                    </div>
                </div>
              
                <div class="col-12 col-md-4" style="text-align: center;">
                <div class="footer-single-widget">
                        <ul class="footer-menu  justify-content-between">                       
                            <li class="nav-item active">
                                <a class="nav-link cus-link" href="<?php echo site_url('du-an.html')?>">Dự Án <span class="sr-only">(current)</span></a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link cus-link" href="<?php echo site_url('nha-pho-thuong-mai.html')?>">Nhà Phố <span class="sr-only">(current)</span></a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link cus-link" href="<?php echo site_url('tuyen-dung.html')?>">Tuyển Dụng <span class="sr-only">(current)</span></a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link cus-link" href="<?php echo site_url('bai-viet-hay.html')?>">Bài Viết Hay <span class="sr-only">(current)</span></a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-12 col-md-4">
                    <div class="footer-single-widget">
                    <h5 class="title" style="font-family:arial;">Liên hệ ngay</h5>
                        <ul class="footer-menu  justify-content-between">                       
                            <li class="nav-item active">
                                <a class="nav-link cus-link"  href="#"><?php echo $supports->name?></a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link cus-link"  href="#"><?php echo $supports->address?></a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link cus-link"  href="tel:<?php echo $supports->phone?>"><?php echo $supports->phone?></a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link cus-link"  href="mailto:<?php echo $supports->gmail?>"><?php echo $supports->gmail?></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-md-12">
                    <span style="color:#fff;border-top:1px solid #fff;"> <br/>Copyright &copy;<script>document.write(new Date().getFullYear());</script> Nhà đất Phạm Văn Lên <i class="fa fa-heart-o" aria-hidden="true"></i> </span>
                </div>
            </div>
        </div>