# khoahoc
codeigniter 3.x , Khoa học công nghệ, introduce website,

#Edit file database location in database.php and siteURL in config.php(\application\config)
