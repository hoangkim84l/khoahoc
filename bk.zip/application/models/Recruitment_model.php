<?php
Class Recruitment_model extends MY_Model
{
    var $table = 'maker';
}