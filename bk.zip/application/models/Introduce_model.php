<?php
Class Introduce_model extends MY_Model
{
    var $table = 'info';
}