﻿<!DOCTYPE html>
<html lang="en" class="wow-animation">
    <head>
	  <?php $this->load->view('site/head');?>
	
    </head>
    <body>
	<div class="main-wrapper">	
		<!--========== Youtube Video ==========-->
		<div class="video-wrapper">
			<div class="player" data-property="{ videoURL:'https://www.youtube.com/watch?v=0pXYp72dwl0' }"></div>
		</div>		
	           <div class="header-area">
	                 <?php $this->load->view('site/header')?>
	           </div>	 
		<main class="main-container">               
	           <div id="container">
	                <div class="hero-area">
	                      <?php if(isset($message)):?>
	                      <h3 style="color:red"><?php echo $message?></h3>
	                      <?php endif;?>
	                      <?php $this->load->view($temp , $this->data);?>
	                </div>
	                 
	                  <div class="clear"></div>
	           </div>	
		</main>     	       
		<div class="footer">
			
	    </div>
	    
    </body>
</html>