﻿<header class="slider-header">
<a href="#popup-form" class="icon fa fa-phone popup-with-zoom-anim"></a>
<a href="<?php echo site_url();?>"><img src="<?php echo public_url()?>/site/img/logo.png" class="logotype" width="200" height="80" alt=""></a>
<a href="#popup-map" class="icon fa fa-map-marker popup-with-zoom-anim"></a>

<div id="popup-map" class="zoom-anim-dialog mfp-hide">
    <div class="popup-cont">
    <div data-text="Tân An, Long An, Việt Nam" data-x-coord="10.537302" data-y-coord="106.405666" class="map" id="google-map"></div>
    </div>
</div>

<div id="popup-form" class="zoom-anim-dialog mfp-hide">
    <div class="popup-cont form all-dark">
    <p><a href="tel:<?php echo $supports->phone?>"><?php echo $supports->phone?></a></p>
    </div>
</div>
</header>