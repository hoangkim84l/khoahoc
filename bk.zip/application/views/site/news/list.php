  <!-- ********** Hero Area Start ********** -->
  <div class="hero-area height-400 bg-img background-overlay" style="background-image: url(<?php echo public_url()?>/site/img/blog-img/bg3.jpg);"></div>
    <!-- ********** Hero Area End ********** -->

    <div class="main-content-wrapper section-padding-100">
        <div class="container">
            <div class="row justify-content-center">
                <!-- ============= Post Content Area Start ============= -->
                <div class="col-12 col-lg-8">
                    <div class="post-content-area mb-100">
                        <!-- Catagory Area -->
                        <div class="world-catagory-area">
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <li class="title">Bài viết mới</li>                               
                            </ul>

                            <div class="tab-content" id="myTabContent">
							<?php if(empty($list)):?>
						           <h2 style='text-align:center'>Chưa có bài viết nào</h2>
						    <?php else:?>
								<?php foreach ($list as $row): ?>
                                <div class="tab-pane fade show active" id="world-tab-1" role="tabpanel" aria-labelledby="tab1">
                                    <!-- Single Blog Post -->
                                    <div class="single-blog-post post-style-4 d-flex align-items-center">
                                        <!-- Post Thumbnail -->
                                        <div class="post-thumbnail">
                                            <img src="<?php echo base_url('upload/news/'.$row->image_link)?>" alt="<?php echo $row->meta_key; ?>" title="<?php echo $row->meta_desc; ?>">
                                        </div>
                                        <!-- Post Content -->
                                        <div class="post-content">
                                            <a href="<?=site_url('bai-viet/chi-tiet/'.$row->slug_title.'-'.$row->id)?>" class="headline">
                                                <h5 style="overflow: hidden;
															text-overflow: ellipsis;
															white-space: pre;
															width:100%;
															"><?php echo $row->title; ?></h5>
                                            </a>
                                            <p><?php echo $row->intro; ?></p>
                                            <!-- Post Meta -->
                                            <div class="post-meta">
                                                <p><a href="#" class="post-author">Nguồn <?php echo $row->author; ?></a> on <a href="#" class="post-date"><?php echo mdate('%d-%m-%Y',$row->created)?> - <?php echo $row->count_view?> lượt xem</a></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
								<?php endforeach; ?>
							<?php endif;?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ========== Sidebar Area ========== -->
                <div class="col-12 col-md-8 col-lg-4">
                    <div class="post-sidebar-area">
                        <!-- Widget Area -->
                        <div class="sidebar-widget-area">
                            <h5 class="title">Xem Nhiều Nhất</h5>
                            <div class="widget-content">
							<?php if(empty($maxView)):?>
						           <h2 style='text-align:center'>Chưa có bài viết nào</h2>
						    <?php else:?>
								<?php foreach ($maxView as $row2): ?>
                                <!-- Single Blog Post -->
                                <div class="single-blog-post post-style-2 d-flex align-items-center widget-post">
                                    <!-- Post Thumbnail -->
                                    <div class="post-thumbnail">
										<img src="<?php echo base_url('upload/news/'.$row2->image_link)?>" alt="<?php echo $row2->meta_key; ?>" title="<?php echo $row2->meta_desc; ?>">
                                     </div>
                                    <!-- Post Content -->
                                    <div class="post-content">
									<a href="<?=site_url('bai-viet/chi-tiet/'.$row2->slug_title.'-'.$row2->id)?>" class="headline">
                                                <h5 style="overflow: hidden;
															text-overflow: ellipsis;
															white-space: pre;
															width:60%;
															"><?php echo $row2->title; ?></h5>
                                            </a>
                                    </div>
                                </div>
                                <?php endforeach; ?>
							<?php endif;?>
                            </div>
                        </div>
                     
                    </div>
                </div>
            </div>

            <!-- Load More btn -->
            <div class="row">
                <div class="col-12">
                    <!-- <div class="load-more-btn mt-50 text-center"> -->
					<div class='pagination_news'>
		            	<?php echo $this->pagination->create_links();?>
		            </div>
                    <!-- </div> -->
                </div>
            </div>
        </div>
    </div>
