<div class="hero-post-area">		
	<img src="<?php echo public_url('site')?>/img/bt.png" alt="bất động sản Trần Anh" title="bất động sản Trần Anh" class="img-responsive">		
</div>